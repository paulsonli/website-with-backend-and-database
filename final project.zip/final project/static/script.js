const item1 = 12.50;
const item2 = 7.50;
const item3 = 7.50;
const item4 = 26.00;
const item5 = 37.50;
const item6 = 37.50;

let total = 0.00;
$(".totalCost").html(`${total}`)

buyList = []


$("#add2Bag1").click(function () {

    $(".cartList").append(`<li>Cherry Blossom Hand Lotion - $${item1}</li>`)
    total += item1;
    $(".totalCost").html(`${total}`);
    
    buyList.push(1);
});

$("#add2Bag2").click(function () {

    $(".cartList").append(`<li>Himalaya Honey Body Cream - $${item2}</li>`)
    total += item2;
    $(".totalCost").html(`${total}`)

    buyList.push(2);
});

$("#add2Bag3").click(function () {

    $(".cartList").append(`<li>Organic Rice Milk Body Cream - $${item3}</li>`)
    total += item3;
    $(".totalCost").html(`${total}`)

    buyList.push(3);
});

$("#add2Bag4").click(function () {

    $(".cartList").append(`<li>Renewing Treat Gift Set - $${item4}</li>`)
    total += item4;
    $(".totalCost").html(`${total}`)

    buyList.push(4);
});

$("#add2Bag5").click(function () {

    $(".cartList").append(`<li>Rebalancing Ritual Gift Set - $${item5}</li>`)
    total += item5;
    $(".totalCost").html(`${total}`)

    buyList.push(5);
});

$("#add2Bag6").click(function () {

    $(".cartList").append(`<li>Soothing Ritual Gift Set - $${item6}</li>`)
    total += item6;
    $(".totalCost").html(`${total}`)

    buyList.push(6);
});



// send to backend
function sendData(){
    

    $.post("/item_data", {"buy_list": buyList});

    console.log(buyList);

}

$("#buy").click(function(){

    sendData();

});



