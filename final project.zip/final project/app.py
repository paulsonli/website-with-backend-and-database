from unittest import result
from flask import Flask, jsonify, redirect, render_template, request
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import false
from sqlalchemy.sql import func
import time

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:SQL420362@localhost/Lotions'
db = SQLAlchemy(app)


class Buyer(db.Model):
    __tablename__ = "buyer"
    buyer_id = db.Column(db.Integer, primary_key = True)
    first_name = db.Column(db.String(30))
    last_name = db.Column(db.String(30))
    address = db.Column(db.String(100))
    credit_card = db.Column(db.String(16))

    def __init__(self, first_name, last_name, address, credit_card):
        self.first_name = first_name
        self.last_name = last_name
        self.address = address
        self.credit_card = credit_card


class Items(db.Model):
    __tablename__ = "items"
    item_id = db.Column(db.Integer, primary_key = True)
    item_name = db.Column(db.String(50))
    item_price = db.Column(db.Float)

    def __init__(self, item_id, item_name):
        self.item_id = item_id

    

class BuyerItems(db.Model):
    __tablename__ = "buyer_items"
    buyer_id = db.Column(db.Integer, primary_key = True, nullable = False, autoincrement = True)
    items_id = db.Column(db.Integer, primary_key = True, nullable = False, autoincrement = True)

    def __init__(self, buyer_id, items_id):
        self.buyer_id = buyer_id
        self.items_id = int(items_id)


@app.route("/")
def index():
    return render_template("index.html")

# send buyer information ##############################

@app.route("/", methods=["POST"])
def buyerInfo():
    
    if request.method == "POST":
        firstName = request.form["first_name"]
        lastName = request.form["last_name"]
        address = request.form["address"]
        creditCard = request.form["creditCard"]


        print(firstName, "FORM~~~~~~")


        buyerData = Buyer(firstName, lastName, address, creditCard)
        db.session.add(buyerData)
        db.session.commit()

        
    
        #print(buyerData.buyer_id)

        
        return render_template("thankyou.html")
        
    else:
        return render_template("index.html")

# send item information###################

    
@app.route("/item_data", methods=["POST"])
def buyerItems():

    if request.method == "POST":


        items_id =  request.form.getlist('buy_list[]')


        time.sleep(1)

        buyer_id_list = db.session.query(func.max(Buyer.buyer_id)).one()
        buyer_id = buyer_id_list[0]

        
        for i in items_id:
            
            buyer_items = BuyerItems(buyer_id, i)
            db.session.add(buyer_items)


        db.session.commit()
        print("COMMITED")
        


        return request.form



if __name__ == '__main__':
    app.debug = True
    app.run()